/** @type {import('@react-native-community/cli-types').UserDependencyConfig} */
module.exports = {
  dependency: {
    platforms: {
      android: {
        sourceDir: 'android',
        packageImportPath:
          'import com.akashskypatel.ffmpegkitextended.FFmpegKitExtendedPackage;',
        packageInstance: 'new FFmpegKitExtendedPackage()',
        cmakeListsPath: 'generated/jni/CMakeLists.txt',
        cxxModuleCMakeListsModuleName: 'react_native_ffmpeg_kit_extended',
        cxxModuleCMakeListsPath: 'CMakeLists.txt',
        cxxModuleHeaderName: 'FFmpegKitExtendedImpl',
      },
    },
  },
};
