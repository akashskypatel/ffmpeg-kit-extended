import { FFplaySession } from './session';
import type { ExecuteOptions } from './types';
export declare class FFplayKit {
    private static activeSession?;
    static createSession(command: string, timeoutMs?: number): FFplaySession;
    static execute(command: string, options?: ExecuteOptions<FFplaySession>, timeoutMs?: number): Promise<FFplaySession>;
    static executeAsync(command: string, options?: ExecuteOptions<FFplaySession>, timeoutMs?: number): Promise<FFplaySession>;
    static cancel(session: FFplaySession): void;
    static getCurrentSession(): FFplaySession | undefined;
    static get currentSession(): FFplaySession | undefined;
    static get playing(): boolean;
    static get paused(): boolean;
    static hasVideoStream(path: string): boolean;
    static getFFplaySessions(): FFplaySession[];
}
//# sourceMappingURL=ffplay-kit.d.ts.map