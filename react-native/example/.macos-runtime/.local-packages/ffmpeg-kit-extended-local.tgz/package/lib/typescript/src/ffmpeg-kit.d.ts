import { FFmpegSession } from './session';
import type { FFmpegExecuteOptions } from './types';
export declare class FFmpegKit {
    static createSession(command: string): FFmpegSession;
    static createSessionFromArguments(arguments_: readonly string[]): FFmpegSession;
    /**
     * React Native execution is asynchronous by design so FFmpeg never blocks
     * the JavaScript runtime. The promise resolves when the session completes.
     */
    static execute(command: string, options?: FFmpegExecuteOptions<FFmpegSession>): Promise<FFmpegSession>;
    static executeAsync(command: string, options?: FFmpegExecuteOptions<FFmpegSession>): Promise<FFmpegSession>;
    static cancel(session: FFmpegSession): void;
    static getLastFFmpegSession(): FFmpegSession | undefined;
    static getFFmpegSessions(): FFmpegSession[];
}
//# sourceMappingURL=ffmpeg-kit.d.ts.map