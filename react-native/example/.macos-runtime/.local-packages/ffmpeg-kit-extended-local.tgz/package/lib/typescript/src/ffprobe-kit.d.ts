import { FFprobeSession, MediaInformationSession } from './session';
import type { ExecuteOptions } from './types';
export declare class FFprobeKit {
    static createSession(command: string): FFprobeSession;
    static execute(command: string, options?: ExecuteOptions<FFprobeSession>): Promise<FFprobeSession>;
    static executeAsync(command: string, options?: ExecuteOptions<FFprobeSession>): Promise<FFprobeSession>;
    static cancel(session: FFprobeSession): void;
    static createMediaInformationSession(path: string, timeoutMs?: number): MediaInformationSession;
    static getMediaInformation(path: string, timeoutMs?: number): Promise<MediaInformationSession>;
    static getLastFFprobeSession(): FFprobeSession | undefined;
    static getFFprobeSessions(): FFprobeSession[];
}
//# sourceMappingURL=ffprobe-kit.d.ts.map