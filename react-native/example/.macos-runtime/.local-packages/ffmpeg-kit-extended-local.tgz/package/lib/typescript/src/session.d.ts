import type { ExecuteOptions, FFmpegExecuteOptions, Log, SessionSnapshot, SessionType, Statistics } from './types';
import { SessionState } from './types';
import { MediaInformation } from './media-information';
export declare abstract class Session {
    readonly sessionId: number;
    readonly command: string;
    readonly type: SessionType;
    private cancelled;
    protected constructor(sessionId: number, command: string, type: SessionType);
    get isCancelled(): boolean;
    getState(): SessionState;
    getReturnCode(): number;
    getSessionId(): number;
    getCreateTime(): Date;
    getStartTime(): Date;
    getEndTime(): Date;
    getDuration(): number;
    getCommand(): string;
    getOutput(): string;
    getLogsAsString(): string;
    getFailStackTrace(): string;
    getLogsCount(): number;
    getStatisticsCount(): number;
    cancel(): void;
    enableDebugLog(): void;
    disableDebugLog(): void;
    isDebugLogEnabled(): boolean;
    getDebugLog(): string;
    clearDebugLog(): void;
    isFFmpegSession(): this is FFmpegSession;
    isFFprobeSession(): this is FFprobeSession;
    isFFplaySession(): this is FFplaySession;
    isMediaInformationSession(): this is MediaInformationSession;
    protected snapshot(): SessionSnapshot;
    protected monitor<T extends Session>(self: T, options: ExecuteOptions<T> & {
        statisticsCallback?: (statistics: Statistics, session: T) => void;
    }): Promise<T>;
}
export declare class FFmpegSession extends Session {
    private completeCallback?;
    private logCallback?;
    private statisticsCallback?;
    constructor(sessionId: number, command: string);
    setCompleteCallback(callback?: (session: FFmpegSession) => void): void;
    removeCompleteCallback(): void;
    setLogCallback(callback?: (log: Log, session: FFmpegSession) => void): void;
    removeLogCallback(): void;
    setStatisticsCallback(callback?: (statistics: Statistics, session: FFmpegSession) => void): void;
    removeStatisticsCallback(): void;
    executeAsync(options?: FFmpegExecuteOptions<FFmpegSession>): Promise<this>;
}
export declare class FFprobeSession extends Session {
    private completeCallback?;
    private logCallback?;
    constructor(sessionId: number, command: string);
    setCompleteCallback(callback?: (session: FFprobeSession) => void): void;
    removeCompleteCallback(): void;
    setLogCallback(callback?: (log: Log, session: FFprobeSession) => void): void;
    removeLogCallback(): void;
    executeAsync(options?: ExecuteOptions<FFprobeSession>): Promise<this>;
}
export declare class MediaInformationSession extends Session {
    private completeCallback?;
    private logCallback?;
    private timeoutMs;
    constructor(sessionId: number, command: string, timeoutMs?: number);
    setCompleteCallback(callback?: (session: MediaInformationSession) => void): void;
    removeCompleteCallback(): void;
    setLogCallback(callback?: (log: Log, session: MediaInformationSession) => void): void;
    removeLogCallback(): void;
    setTimeout(timeoutMs: number): void;
    executeAsync(options?: ExecuteOptions<MediaInformationSession>): Promise<this>;
    getMediaInformation(): MediaInformation | undefined;
}
export declare class FFplaySession extends Session {
    private completeCallback?;
    private cachedVolume;
    private logCallback?;
    private timeoutMs;
    constructor(sessionId: number, command: string, timeoutMs?: number);
    setCompleteCallback(callback?: (session: FFplaySession) => void): void;
    removeCompleteCallback(): void;
    setLogCallback(callback?: (log: Log, session: FFplaySession) => void): void;
    removeLogCallback(): void;
    setTimeout(timeoutMs: number): void;
    executeAsync(options?: ExecuteOptions<FFplaySession>): Promise<this>;
    start(): void;
    pause(): void;
    resume(): void;
    stop(): void;
    seek(seconds: number): void;
    getPosition(): number;
    setPosition(seconds: number): void;
    getMediaDuration(): number;
    getVideoWidth(): number;
    getVideoHeight(): number;
    isPlaying(): boolean;
    isPaused(): boolean;
    setVolume(volume: number): void;
    getVolume(): number;
}
export declare function sessionFromSnapshot(snapshot: SessionSnapshot): Session;
export declare function parseSessionJson(json: string): Session | undefined;
export declare function parseSessionsJson(json: string): Session[];
//# sourceMappingURL=session.d.ts.map