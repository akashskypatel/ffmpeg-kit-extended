import { LogLevel, SessionState, Signal } from './types';
export declare class FFmpegKitConfig {
    static enableRedirection(): void;
    static disableRedirection(): void;
    static setLogLevel(level: LogLevel): void;
    static getLogLevel(): LogLevel;
    static logLevelToString(level: LogLevel): string;
    static setFontDirectory(path: string, mapping?: Record<string, string>): void;
    static setEnvironmentVariable(name: string, value: string): void;
    static ignoreSignal(signal: Signal): void;
    static setAudioOutputDevice(deviceName: string): void;
    static listAudioOutputDevices(): string;
    static getFFmpegVersion(): string;
    static getVersion(): string;
    static getPackageName(): string;
    static setSessionHistorySize(size: number): void;
    static getSessionHistorySize(): number;
    static clearSessions(): void;
    static registerNewFFmpegPipe(): string | undefined;
    static closeFFmpegPipe(path: string): void;
    static sessionStateToString(state: SessionState): string;
    static parseArguments(command: string): string[];
    static argumentsToString(arguments_: readonly string[]): string;
    static messagesInTransmit(sessionId: number): number;
    static getMaxConcurrentSessions(): number;
    static setMaxConcurrentSessions(value: number): void;
}
//# sourceMappingURL=ffmpeg-kit-config.d.ts.map