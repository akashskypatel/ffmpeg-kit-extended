/**
 * Formats an argv-style array as a command string accepted by FFmpegKit.
 * This intentionally performs only shell-style quoting; the native FFmpegKit
 * parser remains the authority when the command is executed.
 */
export declare function argumentsToString(arguments_: readonly string[]): string;
/**
 * Parses the common quoting/escaping forms used in FFmpegKit command strings.
 * It is deliberately small and deterministic rather than trying to emulate a
 * platform shell.
 */
export declare function parseArguments(command: string): string[];
//# sourceMappingURL=arguments.d.ts.map