export declare class SessionCancelledException extends Error {
    constructor(message?: string);
}
type CancellableSession = {
    cancel(): void;
};
export declare class SessionQueueManager {
    private static readonly instance;
    static get shared(): SessionQueueManager;
    private maxConcurrent;
    private readonly active;
    private readonly queue;
    get activeSessions(): CancellableSession[];
    get activeSessionCount(): number;
    get queueLength(): number;
    get isBusy(): boolean;
    get maxConcurrentSessions(): number;
    set maxConcurrentSessions(value: number);
    executeSession<T>(session: CancellableSession, executor: () => Promise<T>): Promise<T>;
    cancelCurrent(): void;
    clearQueue(): void;
    cancelAll(): void;
    waitForAll(): Promise<void>;
    private processQueue;
}
export {};
//# sourceMappingURL=session-queue-manager.d.ts.map