export interface StreamInformationData {
    index?: number;
    type?: string;
    codec?: string;
    codecLong?: string;
    format?: string;
    width?: number;
    height?: number;
    bitrate?: string;
    sampleRate?: string;
    sampleFormat?: string;
    channelLayout?: string;
    sampleAspectRatio?: string;
    displayAspectRatio?: string;
    averageFrameRate?: string;
    realFrameRate?: string;
    timeBase?: string;
    codecTimeBase?: string;
    tagsJson?: string;
    allPropertiesJson?: string;
}
export declare class StreamInformation implements StreamInformationData {
    index?: number;
    type?: string;
    codec?: string;
    codecLong?: string;
    format?: string;
    width?: number;
    height?: number;
    bitrate?: string;
    sampleRate?: string;
    sampleFormat?: string;
    channelLayout?: string;
    sampleAspectRatio?: string;
    displayAspectRatio?: string;
    averageFrameRate?: string;
    realFrameRate?: string;
    timeBase?: string;
    codecTimeBase?: string;
    tagsJson?: string;
    allPropertiesJson?: string;
    constructor(data: StreamInformationData);
    get tags(): Record<string, unknown> | undefined;
    get allProperties(): Record<string, unknown> | undefined;
}
export interface ChapterInformationData {
    id?: number;
    timeBase?: string;
    start?: number;
    startTime?: string;
    end?: number;
    endTime?: string;
    tagsJson?: string;
    allPropertiesJson?: string;
}
export declare class ChapterInformation implements ChapterInformationData {
    id?: number;
    timeBase?: string;
    start?: number;
    startTime?: string;
    end?: number;
    endTime?: string;
    tagsJson?: string;
    allPropertiesJson?: string;
    constructor(data: ChapterInformationData);
    get tags(): Record<string, unknown> | undefined;
    get allProperties(): Record<string, unknown> | undefined;
}
export interface MediaInformationData {
    filename?: string;
    format?: string;
    longFormat?: string;
    duration?: string;
    startTime?: string;
    bitrate?: string;
    size?: string;
    tagsJson?: string;
    allPropertiesJson?: string;
    streams?: StreamInformationData[];
    chapters?: ChapterInformationData[];
}
export declare class MediaInformation {
    readonly filename?: string;
    readonly format?: string;
    readonly longFormat?: string;
    readonly duration?: string;
    readonly startTime?: string;
    readonly bitrate?: string;
    readonly size?: string;
    readonly tagsJson?: string;
    readonly allPropertiesJson?: string;
    readonly streams: StreamInformation[];
    readonly chapters: ChapterInformation[];
    constructor(data: MediaInformationData);
    get tags(): Record<string, unknown> | undefined;
    get allProperties(): Record<string, unknown> | undefined;
}
//# sourceMappingURL=media-information.d.ts.map