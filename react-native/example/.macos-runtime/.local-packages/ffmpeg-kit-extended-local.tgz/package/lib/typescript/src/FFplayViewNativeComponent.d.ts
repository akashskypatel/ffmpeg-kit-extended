import type { HostComponent, ViewProps } from 'react-native';
export interface NativeProps extends ViewProps {
}
declare const _default: HostComponent<NativeProps>;
export default _default;
//# sourceMappingURL=FFplayViewNativeComponent.d.ts.map