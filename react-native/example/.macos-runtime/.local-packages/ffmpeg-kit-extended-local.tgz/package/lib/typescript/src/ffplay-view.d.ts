import React from 'react';
import { type ViewProps } from 'react-native';
export type FFplayViewProps = ViewProps;
export declare function FFplayView(props: FFplayViewProps): React.JSX.Element;
//# sourceMappingURL=ffplay-view.d.ts.map